# space-invaders
A vanilla JavaScript game with HTML and CSS

View the full walkthrough [here](https://www.youtube.com/channel/UC5DNytAJ6_FISueUfzZCVsw) 

I have kept the styling at a bare miniumum for you to go wild and make it your own. Please tag me as I would LOVE to see your game!!!

Space Invaders is a simple grid-based game in which you as the shooter have to shoot down as many alien invaders before they get to you. We are going to build a 15 x 15 grid square with 20 invaders to shoot. 

In this repo, I will be putting extra focus on for loops and classLists in JavaScript. If you want to learn how to use these loops and classLists effectively, please have a look at my code.


### We are also going to be looking at:
* for loops
* addEventListener
* classList
* document.querySelector
* Timeout
* switch case

As always I have kept the styling at a bare minimum for you to go wild and make it your own.
