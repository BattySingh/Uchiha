# Nokia3310-Snake
A vanilla JavaScript game with tutorial

For the full walkthrough to coding the game, please visit [here](https://www.youtube.com/watch?v=GWPGz9hrVMk)

I have kept the styling at a bare miniumum for you to go wild and make it your own. Please tag me as I would LOVE to see your game!!!

A vanilla JavaScript grid-based game | In this tutorial you will learn how to make a fully functional game of Nokia 3310 Snake. This is a total BEGINNERS introduction to JavaScript, in which you will cover the following:

* project set up
* linking your JavaScript and CSS files to your HTML file
* event listeners
* query Selectors
* arrow functions
* forEach
* setting time intervals and countdowns

 
